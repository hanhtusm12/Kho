<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel = "stylesheet" type= "text/css" href ="view_bh.css"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

  </head>
  <body>
  <?php 
    $host='localhost';
    $user='root';
    $pass='';
    $db_name='testing';
    
    if(isset($_GET['id2'])){
        $id = $_GET['id2'];
    }
    // Create connection
    $conn=mysqli_connect($host,$user,$pass,$db_name);// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
        $sql="select id,image,TenBH,CS, TenCM, Mota from bh, chuyen_muc, cm_bh where bh.id = cm_bh.id_bh and chuyen_muc.cm_id = cm_bh.id_cm and id = ".$id;
            if($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) > 0){
                    $row = mysqli_fetch_array($result);
                }
            }
    ?>
    <style>
        /* th {
                text-align:right;
        } */
        /* .th_titl{
            transform: translate(30px,0);
        } */
        h1{
            text-align: center;
        }
        /* button{
            margin-left: 50%;
        } */
        .bt{
            margin-right:50%;
            text-align:center;
        }
        /* .bt1{
            margin-left:40%;
        } */
        .btn{
            margin-left:50%
        }

    </style>
    <form method="post">
        <h1>Chi Tiết</h1>
            <div class="ip">
                <table class="table">
                    <thead>
                        <tr class="ok">
                            <th class="th_titl" style="width: 124px;">Ảnh</th>
                            <th><img name = "image" style="width: 100px; height: 120px;" src="<?php echo $row['image']; ?>"></th>
                        </tr>
                        <tr class="ok">
                            <th class="th_titl" style="width: 124px;">Tên Bài Hát</th>
                            <th><input type="text" name ="TenBH" style="width: 508px;" value="<?php echo $row['TenBH']  ?>"readonly></th>
                        </tr>
						<tr class="ok">
                            <th class="th_titl" style="width: 124px;">Ca Sĩ</th>
                            <th><input type="text" name ="CS" style="width: 508px;" value="<?php echo $row['CS']  ?>"readonly></th>
                        </tr>
						<tr class="ok">
                            <th class="th_titl" style="width: 124px;">Chuyên Mục</th>
                            <th><input type="text" name ="TenCM" style="width: 508px;" value="<?php echo $row['TenCM']  ?>"readonly></th>
                        </tr>
						<tr class="ok">
                            <th class="th_titl" style="width: 124px;">Mô tả</th>
                            <th><input type="text" name ="Mota" style="width: 508px;" value="<?php echo $row['Mota']  ?>"readonly></th>
                        </tr>
                    </thead>
                </table>
            </div>
            <a style="margin-right: 40%; margin-bottom:5px" class="btn btn-primary" href="MuZiks.php" role="button"><i class="fas fa-backspace"></i> BACK</a>
            <!-- <button class="bt"><a style="margin-right: 40%; margin-bottom:5px" href="index.php" >BACK</a></button> -->

    </form>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>