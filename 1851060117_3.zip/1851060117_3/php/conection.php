
<?php
session_start();
if(isset($_POST['conection']))
{
 $server_username = "root";
$server_password = "";
$server_host = "localhost";
$database = 'kungfuphp';

$conn = mysqli_connect($server_host,$server_username,$server_password,$database) or die("không thể kết nối tới database");
mysqli_query($conn,"SET NAMES 'UTF8'");

 $email=$_POST['username'];
 $pass=$_POST['password'];
 $select_data=mysql_query("select * from users where username='$username' and password='$pass'");
 if($row=mysql_fetch_array($select_data))
 {
  $_SESSION['username']=$row['username'];
  echo "success";
 }
 else
 {
  echo "fail";
 }
 exit();
}
?>