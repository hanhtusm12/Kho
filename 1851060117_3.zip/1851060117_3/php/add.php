<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel = "stylesheet" type= "text/css" href ="add.css"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

  </head>
  <body>

  <?php
    $host='localhost';
    $uer='root';
    $pass='';
    $db_name='testing';
    // Create connection
    $conn=mysqli_connect($host,$uer,$pass,$db_name);// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    if(isset($_POST['submit'])){
        $id = $_POST['email'];
        if(!empty($id)){
        $sql="select * from ss where email = '".$id."'";
            if($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) > 0){
                    header("location:error.php?temp=1");
                }else{ 
                    //$id = $_POST['id'];
					$email = $_POST['email'];
                    $pass = $_POST['password'];
                    $sqln = "insert into ss values ('".$email."','".$pass."'); ";
                    if(mysqli_query($conn,$sqln)){
                        header("location:QLTK.php");
                    }else{header("location:error.php?temp=1");}
                }
            }
			else{header("location:error.php?temp=1");}
        }else{header("location:error.php?temp=1");}
    }
    ?>
    <style>
        /* th {
                text-align: center;
        } */
        h1{
            text-align: center;
        }
        /* button{
            margin-left: 50%;
        } */
        .bt{
            margin-right:40%;
        }
        .bt1{
            margin-left:40%;
        }
    </style>
        <form method="post">
        <h1>ADD FORM</h1>
            <div class="ip">
            <table class="table">
                <thead>
                    <tr class="ok">
                        <th class="th_titl" style="width: 124px;">Email</th>
                        <th><input type="text" name ="email" style="width: 508px;" ></th>
                    </tr>
                    <tr class="ok">
                        <th class="th_titl" style="width: 124px;">Password</th>
                        <th><input type="text" name ="password" style="width: 508px;" ></th>
                    </tr>
                </thead>
            </table>
            </div>
            <button class="bt1" name="submit" style="color:blue"><i class="fas fa-save"></i> SAVE</button>
            <!-- <a style="margin-right: 40%; margin-bottom:5px" class="btn btn-primary" href="index.php" role="button">back</a> -->
            <button class="bt"><a style=" margin-bottom:5px" href="QLTK.php" ><i class="fas fa-backspace"></i> BACK</a></button>
    </form>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>