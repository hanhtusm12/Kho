<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel = "stylesheet" type= "text/css" href ="QLBH.css"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </head>
  <body>
  <style>
    h1{
        text-align: center;
    }
  </style>
  <?php 
    $host='localhost';
    $uer='root';
    $pass='';
    $db_name='testing';
    
    
    // Create connection
    $conn=mysqli_connect($host,$uer,$pass,$db_name);// Check connection
    if (!$conn) {
        die("Connection failed: " );
    }
	$SoSP = !empty($_GET["SoSP"]) ? $_GET["SoSP"]:3;
	$SoTrang = !empty($_GET["trang"]) ? $_GET["trang"]:1;
	$offset = ($SoTrang - 1)* $SoSP;
    $sql="select id,image,TenBH,CS, TenCM, link from bh, chuyen_muc, cm_bh where bh.id = cm_bh.id_bh and chuyen_muc.cm_id = cm_bh.id_cm order by 'id' asc limit ".$SoSP." offset ".$offset."";
            if($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) > 0){
    $TongBG =  mysqli_query($conn," select id,image,TenBH,CS, TenCM, link from bh, chuyen_muc, cm_bh where bh.id = cm_bh.id_bh and chuyen_muc.cm_id = cm_bh.id_cm ");
	$TongBG = $TongBG-> num_rows;
	$TongTrang = ceil($TongBG / $SoSP);
    ?>
    <div class="container">
    <h1>Quản lý bài hát</h1>
    <hr>
		<input class="form-control" id="myInput" type="text" placeholder="Search..">
            <div class="row">
                <table class='table table-bordered table-striped' style="text-align:center">
                    <thead>
                        <tr>
							<th>ID</th>
                            <th>Ảnh</th>
                            <th>Tên bài hát</th>
                            <th>Ca sĩ</th>
                            <th>Chuyên mục</th>
							<th>Link</th>
                        </tr>
                    </thead>
                    <tbody id = "myTable">
                    <?php
                    while ($post=mysqli_fetch_array($result)) {
                    ?>
                        <tr>
							<td><?php echo $post['id'] ?></td>
                            <td><img style="width: 100px; height: 120px;" src="<?php echo $post['image']; ?>"></td>
                            <td><?php echo $post['TenBH'] ?></td>
                            <td><?php echo $post['CS'] ?></td>
                            <td><?php echo $post['TenCM'] ?></td>
							<td><?php echo $post['link'] ?></td>
                            <td><button type="button" class="btn btn-link"><a href="view_bh.php?id2='<?php echo $post['id'] ?>'" title='Update Record' data-toggle='tooltip'><i class="fas fa-eye"></i>VIEW</a></button></td>
                            <td><button type="button" class="btn btn-link"><a href="edit_bh.php?id2='<?php echo $post['id'] ?>'" title='Update Record' data-toggle='tooltip'><i class="fas fa-edit"></i>UPDATE</a></button></td>
                            <td><button type="button" class="btn btn-link"><a href="delete_bh.php?id2='<?php echo $post['id'] ?>'" title='Update Record' data-toggle='tooltip'><i class="fas fa-trash-alt"></i>DELETE</a></button></td>
                        </tr>
                    <?php
                    }
                    ?>
                    </tbody>
                </table>
				<?php include "PhanTrang.php"; ?>
            </div><br>
            <a style="margin-left: 50%;" class="btn btn-primary" href="add_bh.php" role="button"><i class="fas fa-plus"></i> add</a>
    </div>
<?php
        }
    }
?>  
<script src="js/search.js"></script>
  </body>
</html>