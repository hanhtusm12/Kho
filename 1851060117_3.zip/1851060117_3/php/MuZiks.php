<?php
	session_start();
	$host='localhost';
    $user='root';
    $pass='';
    $db_name='testing';
    
    
    // Create connection
    $conn=mysqli_connect($host,$user,$pass,$db_name);// Check connection
    if (!$conn) {
        die("Không thể kết nối đến server !" );
    }
    $sql="select * from bh,chuyen_muc, cm_bh where bh.id = cm_bh.id_bh and chuyen_muc.cm_id = cm_bh.id_cm";
	$result = mysqli_query($conn, $sql);
	
	$sql_ns = "select * from nghesi";
	$result_ns = mysqli_query($conn, $sql_ns);
	
	$sql_cm = "select * from chuyen_muc";
	$result_cm = mysqli_query($conn, $sql_cm);
	
	$sql_qg = "select * from quocgia";
	$result_qg = mysqli_query($conn, $sql_qg);
	
	$sql_tl = "select * from theloai";
	$result_tl = mysqli_query($conn, $sql_tl);
	
	$sql_hd = "select * from hoatdong";
	$result_hd = mysqli_query($conn, $sql_hd);
	if (isset($_GET["id"])){
	$id2 = $_GET["id"];}
	
	if (isset($_GET["id2"])){
	$id1 = $_GET["id2"];}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
	<meta charset = "utf-8"/>
	<meta name ="viewport" content ="width, initial-scale:1"/>
	<title>MuZiks</title>
	<link rel = "stylesheet" type= "text/css" href ="css/MuZiks.css"/>
	<link rel = "stylesheet" type= "text/css" href ="fontawesome-free-5.15.1-web/css/all.css"/>
	<script type ="text/javascript" src = "js/MuZiks.js"></script>
	<script type ="text/javascript" src = "js/player.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
</head>
<body id="body">

<! Logo và thanh tìm kiếm>
	<div id = "top">
	<div class="logo"><a href ="#"><img src = "https://static-zmp3.zadn.vn/skins/zmp3-v5.1/images/logo.png"></a></div>
	<div class = "boxContainer">
		<table class ="elementsContainer">
			<tr>
				<td>
					<input type ="text" placeholder = "Nhập tên bài hát, ca sĩ hoặc mv..." class ="search">
				</td>
				<td>
					<a href = "#"><i class="fas fa-search"></i></a>
				</td>
			</tr>
		</table>
	</div>
<! Menu bar đa cấp >
	<div id ="menu_top">
			<input type = "checkbox" id="check">
					<label for = "check" class ="checkbtn">
					<i class ="fas fa-bars"></i></label>
			<ul class = "root">
				<li><a href="MuZiks.php" title="TRANG CHỦ" >TRANG CHỦ</a></li>
				<li><a href="#" title="ZINGCHART">ZINGCHART</a>
					<ul class ="submenu submenu2">
						<li><a href="#" title="Real Time" >Real Time</a>
							<ul class = "sub">
								<li><a href="#" title="Bài hát" >Bài hát</a></li>
								<li><a href="#" title="MV" >MV</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Tuần" >Tuần</a>
							<ul class = "sub1">
								<li><a class="ds1.2" href="#" title="Bài hát" >Bài hát</a>
								<li><a class="ds1.2" href="#" title="MV" >MV</a>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="US-UK" >US-UK</a>
							<ul class = "sub2">
								<li><a class="ds1.3" href="#" title="Bài hát" >Bài hát</a>
								<li><a class="ds1.3" href="#" title="MV" >MV</a>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="K-POP" >K-POP</a>
							<ul class = "sub3">
								<li><a class="ds1.4" href="#" title="Bài hát" >Bài hát</a>
								<li><a class="ds1.4" href="#" title="MV" >MV</a>
							</ul>
						</li>
					</ul>
				</li>
				<li><a class="ac" href="#" title="MỚI PHÁT HÀNH">MỚI PHÁT HÀNH</a></li>
				<li><a class="ac" href="#" title="TOP 100">TOP 100</a>
				<ul class ="submenu submenu3">
						<li><a href="#" title="Việt Nam" >Việt Nam</a>
							<ul class = "sub4">
								<li><a href="#" title="Bài hát" >Nhạc trẻ</a></li>
								<li><a href="#" title="Nhạc trữ tình" >Nhạc trữ tình</a></li>
								<li><a href="#" title="Quê hương" >Quê hương</a></li>
								<li><a href="#" title="Nhạc cách mạng" >Nhạc cách mạng</a></li>
								<li><a href="#" title="Rap/ Hip hop Việt" >Rap/ Hip hop Việt</a></li>
								<li><a href="#" title="Rock Việt" >Rock Việt</a></li>
								<li><a href="#" title="Dance Việt" >Dance Việt</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Âu Mỹ" >Âu Mỹ</a>
							<ul class = "sub5">
								<li><a href="#" title="Pop" >Pop</a></li>
								<li><a href="#" title="Rock" >Rock</a></li>
								<li><a href="#" title="Rap/ Hip hop" >Rap/ Hip hop</a></li>
								<li><a href="#" title="Country" >Country</a></li>
								<li><a href="#" title="Electronic/ Dance" >Electronic/ Dance</a></li>
								<li><a href="#" title="R&B/ Soul" >R&B/ Soul</a></li>
								<li><a href="#" title="Audiophile" >Audiophile</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Châu Á" >Châu Á</a>
							<ul class = "sub6">
								<li><a href="#" title="Hàn Quốc" >Hàn Quốc </a></li>
								<li><a href="#" title="Nhật Bản" >Nhật Bản</a></li>
								<li><a href="#" title="Hoa Ngữ" >Hoa Ngữ</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Hòa tấu" >Hòa tấu</a>
							<ul class = "sub7">
								<li><a href="#" title="Classical" >Classical</a></li>
								<li><a href="#" title="Piano" >Piano</a></li>
								<li><a href="#" title="Guitar" >Guitar</a></li>
								<li><a href="#" title="Violin" >Violin</a></li>
								<li><a href="#" title="Celo" >Celo</a></li>
								<li><a href="#" title="Saxophone" >Saxophone</a></li>
								<li><a href="#" title="Nhạc cụ khác" >Nhạc cụ khác</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><a class="ac" href="#" title="CHỦ ĐỀ">CHỦ ĐỀ</a>
				<ul class ="submenu submenu4">
				<li><a href="#" title="Đề xuất" >Đề xuất</a>
							<ul class = "sub8">
								<li><a href="#" title="Nhạc hot" >Nhạc hot</a></li>
								<li><a href="#" title="Những bài hits" >Những bài hits</a></li>
								<li><a href="#" title="Nhạc Việt bất hủ" >Nhạc Việt bất hủ</a></li>
								<li><a href="#" title="Nhạc bất hủ Âu Mỹ" >Nhạc bất hủ Âu Mỹ</a></li>
								<li><a href="#" title="K-Pop hits" >K-Pop hits</a></li>
								<li><a href="#" title="Nhạc Thúy Nga" >Nhạc Thúy Nga</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Thể loại" >Thể loại</a>
							<ul class = "sub9">
								<li><a href="#" title="EDM" >EDM</a></li>
								<li><a href="#" title="Aucoutic" >Aucoutic</a></li>
								<li><a href="#" title="Indie" >Indie</a></li>
								<li><a href="#" title="Nhạc không lời" >Nhạc không lời</a></li>
								<li><a href="#" title="Trữ tình & Bolero" >Trữ tình & Bolero</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Tâm trạng" >Tâm trạng</a>
							<ul class = "sub10">
								<li><a href="#" title="Những ngày mưa" >Những ngày mưa</a></li>
								<li><a href="#" title="Tình yêu" >Tình yêu</a></li>
								<li><a href="#" title="Giai điệu buồn" >Giai điệu buồn</a></li>
								<li><a href="#" title="Âm nhạc thư giãn" >Âm nhạc thư giãn</a></li>
								<li><a href="#" title="Motivation" >Motivation</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Hoạt động" >Hoạt động</a>
							<ul class = "sub11">
								<li><a href="#" title="Tập trung" >Tập trung</a></li>
								<li><a href="#" title="Spa- Yoga" >Spa- Yoga</a></li>
								<li><a href="#" title="Cà phê" >Cà phê</a></li>
								<li><a href="#" title="Weekend" >Weekend</a></li>
								<li><a href="#" title="Party" >Party</a></li>
								<li><a href="#" title="Du lịch" >Du lịch</a></li>
							</ul>
						</li>
				</li>
				</ul>
				<li><a class="ac" href="#" title="MV">MV</a>
				<ul class ="submenu submenu5">
						<li><a href="#" title="Việt Nam" >Việt Nam</a>
							<ul class = "sub12">
								<li><a href="#" title="Nhạc trẻ" >Nhạc trẻ</a></li>
								<li><a href="#" title="Nhạc trữ tình" >Nhạc trữ tình</a></li>
								<li><a href="#" title="Dance Việt" >Dance Việt</a></li>
								<li><a href="#" title="Rock Việt" >Rock Việt</a></li>
								<li><a href="#" title="Rap/ Hip hop Việt" >Rap/ Hip hop Việt</a></li>
								<li><a href="#" title="Nhạc Trịnh" >Nhạc Trịnh</a></li>
								<li><a href="#" title="Nhạc Thiếu Nhi" >Nhạc Thiếu Nhi</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Âu Mỹ" >Âu Mỹ</a>
							<ul class = "sub13">
								<li><a href="#" title="Pop" >Pop</a></li>
								<li><a href="#" title="Rock" >Rock</a></li>
								<li><a href="#" title="Rap/ Hip hop" >Rap/ Hip hop</a></li>
								<li><a href="#" title="Country" >Country</a></li>
								<li><a href="#" title="Electronic/ Dance" >Electronic/ Dance</a></li>
								<li><a href="#" title="R&B/ Soul" >R&B/ Soul</a></li>
								<li><a href="#" title="Audiophile" >Audiophile</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Châu Á" >Châu Á</a>
							<ul class = "sub14">
								<li><a href="#" title="Hàn Quốc" >Hàn Quốc </a></li>
								<li><a href="#" title="Nhật Bản" >Nhật Bản</a></li>
								<li><a href="#" title="Hoa Ngữ" >Hoa Ngữ</a></li>
								<li><a href="#" title="Thái Lan" >Thái Lan</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Hòa tấu" >Hòa tấu</a>
							<ul class = "sub15">
								<li><a href="#" title="Classical" >Classical</a></li>
								<li><a href="#" title="Piano" >Piano</a></li>
								<li><a href="#" title="Guitar" >Guitar</a></li>
								<li><a href="#" title="Violin" >Violin</a></li>
								<li><a href="#" title="Celo" >Celo</a></li>
								<li><a href="#" title="Saxophone" >Saxophone</a></li>
								<li><a href="#" title="Nhạc cụ khác" >Nhạc cụ khác</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><a class="ac" href="#" title="ALBUM">ALBUM</a>
				<ul class ="submenu submenu6">
						<li><a href="#" title="Việt Nam" >Việt Nam</a>
							<ul class = "sub12">
								<li><a href="#" title="Nhạc trẻ" >Nhạc trẻ</a></li>
								<li><a href="#" title="Nhạc trữ tình" >Nhạc trữ tình</a></li>
								<li><a href="#" title="Dance Việt" >Dance Việt</a></li>
								<li><a href="#" title="Rock Việt" >Rock Việt</a></li>
								<li><a href="#" title="Rap/ Hip hop Việt" >Rap/ Hip hop Việt</a></li>
								<li><a href="#" title="Nhạc Trịnh" >Nhạc Trịnh</a></li>
								<li><a href="#" title="Nhạc Thiếu Nhi" >Nhạc Thiếu Nhi</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Âu Mỹ" >Âu Mỹ</a>
							<ul class = "sub13">
								<li><a href="#" title="Pop" >Pop</a></li>
								<li><a href="#" title="Rock" >Rock</a></li>
								<li><a href="#" title="Rap/ Hip hop" >Rap/ Hip hop</a></li>
								<li><a href="#" title="Country" >Country</a></li>
								<li><a href="#" title="Electronic/ Dance" >Electronic/ Dance</a></li>
								<li><a href="#" title="R&B/ Soul" >R&B/ Soul</a></li>
								<li><a href="#" title="Audiophile" >Audiophile</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Châu Á" >Châu Á</a>
							<ul class = "sub14">
								<li><a href="#" title="Hàn Quốc" >Hàn Quốc </a></li>
								<li><a href="#" title="Nhật Bản" >Nhật Bản</a></li>
								<li><a href="#" title="Hoa Ngữ" >Hoa Ngữ</a></li>
								<li><a href="#" title="Thái Lan" >Thái Lan</a></li>
							</ul>
						</li>
						<li><a class="ds1" href="#" title="Hòa tấu" >Hòa tấu</a>
							<ul class = "sub15">
								<li><a href="#" title="Classical" >Classical</a></li>
								<li><a href="#" title="Piano" >Piano</a></li>
								<li><a href="#" title="Guitar" >Guitar</a></li>
								<li><a href="#" title="Violin" >Violin</a></li>
								<li><a href="#" title="Celo" >Celo</a></li>
								<li><a href="#" title="Saxophone" >Saxophone</a></li>
								<li><a href="#" title="Nhạc cụ khác" >Nhạc cụ khác</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><a class="ac" href="#" title="NGHỆ SĨ">NGHỆ SĨ</a>
				<ul class ="submenu submenu7"><?php 
				foreach ($result_ns as $row){
				?>
				<li><a href="#" title="Nhạc trẻ" ><?php echo $row["QuocGia"];} ?></a></li>
				</ul>
				</li>
				<li><a class="ac" href="NhacCaNhan.php" title="NHẠC CÁ NHÂN">NHẠC CÁ NHÂN</a></li>
				<li><a class="ac" href="login_form.php" title="ĐĂNG NHẬP"><?php
				if(isset($_SESSION["name"]))
				{  
					echo "<a href='logout.php'>".$_SESSION["name"]."</a>";
				}
				else echo "Đăng nhập"; 
				?>
				</a></li>
			</ul>
	</div>
	</div>
<! Banner >
	<div id ="banner">
		<img name="slide" width = "800" height="400">
	</div>
<! Nội dung>
	<div id ="main">
		<div class ="Anh">
			<?php
				foreach ($result_cm as $cm)
				{if ($cm['cm_id'] == 1){
					$Tencm = $cm['TenCM'];
					}
				}
			?>
			<div class = "ANDC"><a href="#<?php echo $Tencm; ?>" title="<?php echo $Tencm; ?>"><?php 
				echo $Tencm; ?></a></div>
			<div method = "POST" class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 1 and $row['id_cm'] == 1){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href ="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>" ></a><a href = "MuZiks.php?id=<?php echo $id; ?>" title="Thêm vào thư viện" ><i class="far fa-heart"></i></a><a href ="MuZiks.php?id2=<?php echo $id; ?>" onclick="check()"><i class="fas fa-play"></i></a><a href = "#" title="Khác" ><i class="fas fa-align-justify"></i></a></br><a href="MuZiks.php?id2=<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>

			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 2 and $row['id_cm'] == 1){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>"></a><a href = "MuZiks.php?id=<?php echo $id; ?>" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href ="MuZiks.php?id2=<?php echo $id; ?>" onclick="check()"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="MuZiks.php?id2=<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 3 and $row['id_cm'] == 1){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>"></a><a href ="MuZiks.php?id=<?php echo $id; ?>" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href ="MuZiks.php?id2=<?php echo $id; ?>"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="MuZiks.php?id2=<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 4 and $row['id_cm'] == 1){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>"></a><a href = "MuZiks.php?id=<?php echo $id; ?>" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href ="MuZiks.php?id2=<?php echo $id; ?>" onclick="check()"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="MuZiks.php?id2=<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 5 and $row['id_cm'] == 1){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>"></a><a href = "MuZiks.php?id=<?php echo $id; ?>" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href ="MuZiks.php?id2=<?php echo $id; ?>" onclick="check()"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="MuZiks.php?id2=<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<?php
				foreach ($result_cm as $cm)
				{if ($cm['cm_id'] == 2){
					$Tencm = $cm['TenCM'];
					}
				}
			?>
			<div class = "NGD"><a href="#<?php echo $Tencm ;?>" title="<?php echo $Tencm; ?>"><?php echo $Tencm; ?></a></div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 6 and $row['id_cm'] == 2){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a onclick="check()"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 7 and $row['id_cm'] == 2){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 8 and $row['id_cm'] == 2){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 9 and $row['id_cm'] == 2){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 10 and $row['id_cm'] == 2){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div> 
			<?php
				foreach ($result_cm as $cm)
				{if ($cm['cm_id'] == 3){
					$Tencm = $cm['TenCM'];
					}
				}
			?>
			<div class = "MRDCB"><a href="#<?php echo $Tencm; ?>" title="<?php echo $Tencm; ?>"><?php echo $Tencm ?></a></div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 11 and $row['id_cm'] == 3){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>" title="<?php echo $TenBH;?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 12 and $row['id_cm'] == 3){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 13 and $row['id_cm'] == 3){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 14 and $row['id_cm'] == 3){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 15 and $row['id_cm'] == 3){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a></br><a class="cap"><?php echo $TenBH; ?></a>
			</div>
			<?php
				foreach ($result_cm as $cm)
				{if ($cm['cm_id'] == 4){
					$Tencm = $cm['TenCM'];
					}
				}
			?>
			<div class = "AW"><a href="#<?php echo $Tencm; ?>" title="<?php echo $Tencm; ?>"><?php echo $Tencm ?></a></div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 16 and $row['id_cm'] == 4){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 17 and $row['id_cm'] == 4){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 18 and $row['id_cm'] == 4){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 19 and $row['id_cm'] == 4){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 20 and $row['id_cm'] == 4){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<?php
				foreach ($result_cm as $cm)
				{if ($cm['cm_id'] == 5){
					$Tencm = $cm['TenCM'];
					}
				}
			?>
			<div class = "ID"><a href="#<?php echo $Tencm ;?>" title="<?php echo $Tencm; ?>"><?php echo $Tencm ?> </a></div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 21 and $row['id_cm'] == 5){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] ==22 and $row['id_cm'] == 5){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 23 and $row['id_cm'] == 5){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 24 and $row['id_cm'] == 5){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 25 and $row['id_cm'] == 5){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<?php
				foreach ($result_cm as $cm)
				{if ($cm['cm_id'] == 6){
					$Tencm = $cm['TenCM'];
					}
				}
			?>
			<div class = "SN"><a href="#<?php echo $Tencm ;?>" title="<?php echo $Tencm; ?>"><?php echo $Tencm ?></a></div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 26 and $row['id_cm'] == 6){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 27 and $row['id_cm'] == 6){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 28 and $row['id_cm'] == 6){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 29 and $row['id_cm'] == 6){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác"><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
			<div class = "item">
			<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 30 and $row['id_cm'] == 6){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a><a href = "#" title="Thêm vào thư viện"><i class="far fa-heart"></i></a><a href = "#"><i class="fas fa-play"></i></a><a href = "#" title="Khác" ><i class="fas fa-align-justify"></i></a></br><a href="#<?php echo $id; ?>" class="cap" title="<?php echo $TenBH; ?>"><?php echo $TenBH; ?></a>
			</div>
<! Ảnh động >
			<div class = "item31">
				<div class = "ZI ZI1">
				<a href="#"><img src = "lang-kinh-3d_111520332.gif"></a></div>
				<div class = "ZI">
				<a href="#"><img src = "luoi-mat-cao-nhun-nhay-3d_111520463.gif"></a></div>
			</div>
		</div>
<! ZINGCHART >
		<div class = "ZC">
			<div class = "Z">
				<a href="#"><img src = "./ZC/1.jpg"></a></div>
				<div class = "Z">
				<a href="#"><img src = "./ZC/2.jpg"></a></div>
				<div class = "Z">
				<a href="#"><img src = "./ZC/3.png"></a></div>
				<div class = "Z">
				<a href="#"><img src = "./ZC/4.png"></a></div>
		</div>
<! Mới phát hành >
		<?php
				foreach ($result_cm as $cm)
				{if ($cm['cm_id'] == 7){
					$Tencm = $cm['TenCM'];
					}
				}
			?>
		<div class = "MoiPH">
		<div class = "PH"><a href="#<?php echo $Tencm ;?>" title="<?php echo $Tencm; ?>"><?php echo $Tencm ;?></a></div>
			<div class = "P P1">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 31 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<a href ="#<?php echo $id ; ?> " title="<?php echo $TenBH ;?>"><h2><?php echo $TenBH ;?></h2></a>
				<a href = "#<?php echo $CS; ?>"><h2 class ="cs"><?php echo $CS ?></h2></a>
				</div>
				<div class = "P P2">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 32 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<a href = "#<?php echo $TenBH ?>"><h2><?php echo $TenBH ?></h2></a>
				<h2 class="cs"><?php echo $CS ?></h2>
				</div>
				<div class = "P P3">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 33 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<a href = "#<?php echo $TenBH ?>"><h2><?php echo $TenBH ?></h2></a>
				<h2 class="cs"><?php echo $CS ?></h2>
				</div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 34 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "Hiển thị lời"><i class="fas fa-microphone-alt"></i><a><a href = "Khác"><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 35 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 36 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 37 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 38 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 39 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 40 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 41 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 42 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 43 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 44 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 45 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 46 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 47 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 48 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image; ?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 49 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 50 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 51 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 52 and $row['id_cm'] == 7 ){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] ==53  and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
				<div class = "P4">
				<?php
				foreach ($result as $row)
				{
					if ($row['id'] == 54 and $row['id_cm'] == 7){
					$id = $row['id'];
					$TenBH = $row['TenBH'];
					$CS = $row['CS'];
					$image = $row['image'];}
				}
				?>
				<a href="#"><img src = "<?php echo $image ;?>"></a>
				<a href = "#"><i class="fas fa-play"></i></a>
				<h2><?php echo $TenBH ?></h2>
				<h2 class="cs4"><?php echo $CS ?></h2>
				<a href = "#"><i class="fas fa-microphone-alt"></i><a><a><i class="fas fa-ellipsis-h"></i></a></div>
		</div>
<! Album >
		<div class = "ANH2">
		<div class = "QG"><a href="#" title="CHỦ ĐỀ">QUỐC GIA</a></div>
			<div class = "i">
			<?php
				foreach ($result_qg as $qg)
				{
					if ($qg['id'] == 1){
					$id = $qg['id'];
					$TenQG = $qg['TenQG'];
					$image = $qg['image'];}
				}
				?>
				<a href="#<?php echo $TenQG; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenQG; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_qg as $qg)
				{
					if ($qg['id'] == 2){
					$id = $qg['id'];
					$TenQG = $qg['TenQG'];
					$image = $qg['image'];}
				}
				?>
				<a href="#<?php echo $TenQG; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenQG; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_qg as $qg)
				{
					if ($qg['id'] == 3){
					$id = $qg['id'];
					$TenQG = $qg['TenQG'];
					$image = $qg['image'];}
				}
				?>
				<a href="#<?php echo $TenQG; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenQG; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_qg as $qg)
				{
					if ($qg['id'] == 4){
					$id = $qg['id'];
					$TenQG = $qg['TenQG'];
					$image = $qg['image'];}
				}
				?>
				<a href="#<?php echo $TenQG; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenQG; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_qg as $qg)
				{
					if ($qg['id'] == 5){
					$id = $qg['id'];
					$TenQG = $qg['TenQG'];
					$image = $qg['image'];}
				}
				?>
				<a href="#<?php echo $TenQG; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenQG; ?></h2></div>
				<div class = "TL"><a href="#" title="CHỦ ĐỀ">THỂ LOẠI</a></div>
				<div class = "i">
				<?php
				foreach ($result_tl as $tl)
				{
					if ($tl['id'] == 1){
					$id = $tl['id'];
					$TenTL = $tl['TenTL'];
					$image = $tl['image'];}
				}
				?>
				<a href="#<?php echo $TenQG; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenTL; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_tl as $tl)
				{
					if ($tl['id'] == 2){
					$id = $tl['id'];
					$TenTL = $tl['TenTL'];
					$image = $tl['image'];}
				}
				?>
				<a href="#<?php echo $TenQG; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenTL; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_tl as $tl)
				{
					if ($tl['id'] == 3){
					$id = $tl['id'];
					$TenTL = $tl['TenTL'];
					$image = $tl['image'];}
				}
				?>
				<a href="#<?php echo $TenQG; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenTL; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_tl as $tl)
				{
					if ($tl['id'] == 4){
					$id = $tl['id'];
					$TenTL = $tl['TenTL'];
					$image = $tl['image'];}
				}
				?>
				<a href="#<?php echo $TenQG; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenTL; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_tl as $tl)
				{
					if ($tl['id'] == 5){
					$id = $tl['id'];
					$TenTL = $tl['TenTL'];
					$image = $tl['image'];}
				}
				?>
				<a href="#<?php echo $TenQG; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenTL; ?></h2></div>
				<div class = "HD"><a href="#" title="CHỦ ĐỀ">HOẠT ĐỘNG & TÂM TRẠNG</a></div>
				<div class = "i">
				<?php
				foreach ($result_hd as $hd)
				{
					if ($hd['id'] == 1){
					$id = $hd['id'];
					$TenHD = $hd['TenHD'];
					$image = $hd['image'];}
				}
				?>
				<a href="#<?php echo $TenHD; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenHD; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_hd as $hd)
				{
					if ($hd['id'] == 2){
					$id = $hd['id'];
					$TenHD = $hd['TenHD'];
					$image = $hd['image'];}
				}
				?>
				<a href="#<?php echo $TenHD; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenHD; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_hd as $hd)
				{
					if ($hd['id'] == 3){
					$id = $hd['id'];
					$TenHD = $hd['TenHD'];
					$image = $hd['image'];}
				}
				?>
				<a href="#<?php echo $TenHD; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenHD; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_hd as $hd)
				{
					if ($hd['id'] == 4){
					$id = $hd['id'];
					$TenHD = $hd['TenHD'];
					$image = $hd['image'];}
				}
				?>
				<a href="#<?php echo $TenHD; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenHD; ?></h2></div>
				<div class = "i">
				<?php
				foreach ($result_hd as $hd)
				{
					if ($hd['id'] == 5){
					$id = $hd['id'];
					$TenHD = $hd['TenHD'];
					$image = $hd['image'];}
				}
				?>
				<a href="#<?php echo $TenHD; ?>"><img src = "<?php echo $image ;?>"></a><h2><?php echo $TenHD; ?></h2></div>
		</div>
	</div>
<! Footer >
	<div id="footer">
		<div class ="product">Một sản phẩm của Sariel</div>
		<div class = "ft">
			<ul>
				<li><a onclick="mo()">Giới thiệu</a></li>
				<li><a href = "https://mp3.zing.vn/huong-dan/contact">Liên hệ</a></li>
				<li><a href = "https://adtima.vn/lien-he?utm_source=zingmp3&utm_medium=footer">Quảng cáo</a></li>
				<li><a href = "https://docs.google.com/forms/d/e/1FAIpQLSdZSuA1N0y7XgvXyIxlwVL0LPiwR9mqm3YSANM6sGpBFnihzw/viewform">Góp ý</a></li>
				<li><a href = "https://mp3.zing.vn/tnc">Thỏa thuận sử dụng</a></li>
			</ul>
		</div>
	</div>
<! Thanh phát nhạc >
	<?php
	if(isset($_GET['id2'])){
		$sql3 ="select * from bh where id ='".$id1."';";
		$result3= mysqli_query($conn, $sql3);
			foreach ($result3 as $row3){
			$TenBH = $row3["TenBH"];
			$TenCS = $row3["CS"];
			$image = $row3["image"];
			$link = $row3["link"];
	}}
	$email = $_SESSION["name"];
	if (isset($_GET['id'])){
	$sql4 ="insert into ss_bh values('".$email."','".$id2."');";
		if (mysqli_query($conn, $sql4)){
		header("location:MuZiks.php");
	}
	}
	?>
	<div id="barplayer" class ="barplayer">
		<div class = "leftbar">
			<div class="now-playing-bar-left clearfix">
                    <div class = "rotate">
                        <span><img src = "<?php echo $image; ?>"></span>
                    </div>
                    <div class = "name-song-player">
                        <h3 id = "title"><?php echo $TenBH;  ?></h3>
                        <p id = "artist"><?php echo $TenCS; ?></p>
                    </div>
                    <div class = "icon">
                        <i class="far fa-heart"></i><i class="fas fa-ellipsis-h"></i>
                    </div>
		</div>
                <div class="main-content">
        <audio id="player">
            <source src=<?php echo $link;?> type="audio/mp3">
        </audio>
        <div id="audio-player">
            <div class="controls"> 
                <div id="progressbar">
                    <div id="progress"></div>
                </div>

                <div class="time">
                    <span id="curtime">00:00</span>
                    <span id="durtime">00:00</span>
                </div>

                <div class="button-gr">
					<span><i id="loop" class ="fas fa-undo"></i></span>
					<span><i id = "backward" class="fas fa-backward"></i></span>
					<span><i id="playbutton" class = "fas fa-play-circle"></i></span>					
					<span><i id = "forward" class="fas fa-forward"></i></span>
					<span><i id="volume" class = "fas fa-volume-up"></i></span>
                </div>
            </div>
        </div>
    </div>
	<div class = "rightbar"></div>
    </div>  
</div>	
<! Giới thiệu >
		<div id="gt" class="gt">
			<div class ="zmp3-logo"><img src = "https://static-zmp3.zadn.vn/skins/zmp3-v5.1/images/logo.png"></div>
			<div id="1">
			Giấy phép mạng xã hội: 314/GP-BTTTT do <br> Bộ Thông tin và Truyền thông cấp ngày <br> 17/7/2015
			<br>
			<br>
			Chủ quản: Công Ty Cổ Phần VNG
			<br>
			Z06 Đường số 13, phường Tân Thuận Đông,<br> quận 7, thành phố Hồ Chí Minh, Việt Nam</div>	
			<div class="modal-card-foot">
				<button class="butto" tabindex="0" onclick= "dong()">Đóng</button>
			</div></div>		
			</div>
</body>
<script src="gt.js"></script>
<script src="js/main.js"></script>
</html>
