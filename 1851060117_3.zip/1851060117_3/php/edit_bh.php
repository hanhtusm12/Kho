<?php
	error_reporting(0)
?>
<?php
	
	$filename = $_FILES["uploadfile1"]["name"];
	$tempname = $_FILES["uploadfile1"]["tmp_name"];
	$folder = "student/". $filename ;
	move_uploaded_file($tempname,$folder);
?>
<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel = "stylesheet" type= "text/css" href ="edit_bh.css"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

  </head>
  <body>
  <?php 
    $host='localhost';
    $user='root';
    $pass='';
    $db_name='testing';
    $bool = false;
	if (isset($_POST['sm'])){
		$bool = true;
	}
    if(isset($_GET['id2'])){
        $id = $_GET['id2'];
    }
    // Create connection
    $conn=mysqli_connect($host,$user,$pass,$db_name);// Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
        $sql="select * from bh where id = ".$id;
            if($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) > 0){
                    $row = mysqli_fetch_array($result);
                }
            }
	$sql2 ="select * from chuyen_muc";
	$result2 = mysqli_query($conn, $sql2);
    if(isset($_POST['submit'])){
        $id = $_POST['id'];
		$image = $_POST['url'];
        $TenBH = $_POST['TenBH'];
		$CS = $_POST['CS'];
		$link = $_POST["link"];
		$CM = $_POST['chuyen_muc'];
		$TenCM = $_POST['chuyen_muc'];
		$sql3 ="select * from chuyen_muc where TenCM ='".$TenCM."';";
		$result3 = mysqli_query($conn, $sql3);
		foreach ($result3 as $row3){ $query = "update cm_bh set id_cm ='".$row3["cm_id"]."' where id_bh =" .$id;}
        $sqln = "update bh set id='".$id."', image='".$image."', TenBH='".$TenBH."', CS='".$CS."', link='".$link."' where id = ".$id;
        if(mysqli_query($conn,$sqln)){
			if(mysqli_query($conn,$query)){
            header("location:QLBH.php");}
        }
    }
    ?>
    <style>
        /* th {
                text-align: center;
        } */
        /* .th_titl{
            transform: translate(30px,0);
        } */
        h1{
            text-align: center;
        }
        /* button{
            margin-left: 50%;
        } */
        .bt{
            margin-right:40%;
        }
        .bt1{
            margin-left:40%;
        }

    </style>
    <form method="post">
        <h1>UPDATE FORM</h1>
            <div class="ip">
                <table class="table" style="tex-align:center">
                    <thead>
						<tr class="ok">
                            <th class="th_titl" style="width: 124px;">Ảnh</th>
                            <th><img name = "image" style="width: 100px; height: 120px;" <?php if($bool == false){?> src ="<?php echo $row['image']; ?>"<?php } else {?> src='<?php echo $folder; ?>' <?php } ?> ></th>
							<th><input type="text" name ="url" style="width: 508px;" value="<?php if($bool == false){ echo $row['image']; } else { echo $folder; } ?>"></th>
							<form action = "" method = "post" enctype = "multipart/form-data">
						</form>
                        </tr>
						<tr class="ok">
                            <th class="th_titl" style="width: 124px;">ID</th>
                            <th><input type="text" name ="id" style="width: 508px;" value="<?php echo $row['id']  ?>" readonly></th>
                        </tr>
						<tr><form action = "" method = "post" enctype = "multipart/form-data">
						<th><input type="file" name="uploadfile1" value=""/></th>
						<th><input type = "submit" name ="sm" value="Upload File"/></th>
						</form></tr>
                        <tr class="ok">
                            <th class="th_titl" style="width: 124px;">Tên Bài Hát</th>
                            <th><input type="text" name ="TenBH" style="width: 508px;" value="<?php echo $row['TenBH']  ?>"></th>
                        </tr>
						<tr class="ok">
                            <th class="th_titl" style="width: 124px;">Ca Sĩ</th>
                            <th><input type="text" name ="CS" style="width: 508px;" value="<?php echo $row['CS']  ?>"></th>
                        </tr>
						<tr class="ok">
                        <th class="th_titl" style="width: 124px;">Chọn chuyên mục</th>
                        <th><select name = "chuyen_muc" style="width: 124px;"><?php 
						foreach ($result2 as $r)
						{?>
						<option><?php echo $r['TenCM'] ?> </option>
						<?php }
						?></select></th>
                    </tr>
					<tr class="ok">
                            <th class="th_titl" style="width: 124px;">Link</th>
                            <th><input type="text" name ="link" style="width: 508px;" value="<?php echo $row['link']  ?>"></th>
                        </tr>
                    </thead>
                </table>
            </div>
            <!-- <button name="submit">save</button> -->
            <button class="bt1" name="submit" style="color:blue"><i class="fas fa-save"></i> SAVE</button>
            <!-- <a style="margin-right: 40%; margin-bottom:5px" class="btn btn-primary" href="index.php" role="button">back</a> -->
            <button class="bt"><a style="margin-bottom:5px,with:30px" href="QLBH.php" ><i class="fas fa-backspace"></i> BACK</a></button>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>

