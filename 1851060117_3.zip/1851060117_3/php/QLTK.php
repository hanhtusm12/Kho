<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel = "stylesheet" type= "text/css" href ="QLTK.css"/>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </head>
  <body>
  <style>
    h1{
        text-align: center;
    }
  </style>
  <?php 
	session_start();
    $host='localhost';
    $user='root';
    $pass='';
    $db_name='testing';
    
    
    // Create connection
    $conn=mysqli_connect($host,$user,$pass,$db_name);// Check connection
    if (!$conn) {
        die("Connection failed: " );
    }
    $sql="select * from ss";
            if($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) > 0){
            
    ?>
    <div class="container">
    <h1>Quản lý tài khoản</h1>
    <hr>
			<input class="form-control" id="myInput" type="text" placeholder="Search..">
            <div class="row">
                <table class='table table-bordered table-striped' style="text-align:center">
                    <thead>
                        <tr>
                            <th>Email</th>
                            <th>Mật khẩu</th>
                        </tr>
                    </thead>
                    <tbody id="myTable">
                    <?php
                    while ($post=mysqli_fetch_array($result)) {
                    ?>
                        <tr>
                            <td><?php echo $post['email'] ?></td>
                            <td><?php echo $post['password'] ?></td>
                            <td><button type="button" class="btn btn-link"><a href="view.php?id1='<?php echo $post['email'] ?>'" title='Update Record' data-toggle='tooltip'><i class="fas fa-eye"></i>VIEW</a></button></td>
                            <td><button type="button" class="btn btn-link"><a href="update.php?id1='<?php echo $post['email'] ?>'" title='Update Record' data-toggle='tooltip'><i class="fas fa-edit"></i>UPDATE</a></button></td>
                            <td><button type="button" class="btn btn-link"><a href="delete.php?id1='<?php echo $post['email'] ?>'" title='Update Record' data-toggle='tooltip'><i class="fas fa-trash-alt"></i>DELETE</a></button></td>
                        </tr>
                    <?php
                    }
                    ?>
                    </tbody>
                </table>
            </div>
            <a style="margin-left: 50%;" class="btn btn-primary" href="add.php" role="button"><i class="fas fa-plus"></i>Thêm</a>
    </div>
<?php
        }
    }
?>   
<script src="js/search.js"></script>
  </body>
</html>