<?php

//check_login.php

if(isset($_POST["email"]))
{
 $connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

 session_start();

 $query = "SELECT * FROM ss WHERE email = '".$_POST['email']."'";

 $statement = $connect->prepare($query);

 $statement->execute();

 $total_row = $statement->rowCount();

 $output = '';
 
 $password = $_POST["password"];
  
 $email = $_POST["email"];

 if($total_row > 0)
 {
 $output = "Tài khoản đã tồn tại";}
else{
						//thực hiện việc lưu trữ dữ liệu vào db
	$query = "INSERT INTO ss(
	    					email,
							password
	    					) VALUES (
	    					'$email',
							'$password'
	    					)";
	$statement = $connect->prepare($query);

	$statement->execute();
					    // thực thi câu $sql với biến conn lấy từ file connection.php*/
	$output =  "Chúc mừng bạn đã đăng ký thành công";
	}
	echo $output;
}

?>
