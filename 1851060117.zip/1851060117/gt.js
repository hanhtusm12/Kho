var m = document.getElementById("main");
var f = document.getElementById("footer");
var g = document.getElementById("gt");
var b = document.getElementById("barplayer");

function mo(){
	g.style.left="40%";
	m.style.opacity="0.2";
	f.style.opacity="0.2";
	g.style.opacity="2";
}

function dong(){
	g.style.left="-100%";
	m.style.opacity="1";
	f.style.opacity="1";
}

function check(){
	b.style.left="0";
}
