
<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel = "stylesheet" type= "text/css" href ="NhacCaNhan.css"/>
  </head>
  <body>
  <style>
    h1{
        text-align: center;
    }
  </style>
  <?php 
    $host='localhost';
    $user='root';
    $pass='';
    $db_name='testing';
    
    $check = false;
    // Create connection
    $conn=mysqli_connect($host,$user,$pass,$db_name);// Check connection
    if (!$conn) {
        die("Connection failed: " );
    }
	session_start();
	if (!isset($_SESSION["name"])){
    echo "Bạn cần đăng nhập trước";}
	else { $sql="select * from bh,ss_bh,ss where bh.id = ss_bh.ss_id and ss.email = ss_bh.ss_email and ss.email = '".$_SESSION["name"]."';"; $check = true;}
            if ($check == true){
			if($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) > 0){
            
    ?>
    <div class="container">
    <h1>Nhạc cá nhân</h1>
    <hr>
			<input class="form-control" id="myInput" type="text" placeholder="Search..">
            <div class="row">
                <table class='table table-bordered table-striped' style="text-align:center">
                    <thead>
                        <tr>
                            <th>Ảnh</th>
                            <th>Tên bài hát</th>
							<th>Ca sĩ</th>
                        </tr>
                    </thead>
                    <tbody id = "myTable">
                    <?php
                    while ($post=mysqli_fetch_array($result)) {
                    ?>
                        <tr>
                            <td><img style="width: 100px; height: 120px;" src="<?php echo $post['image']; ?>"></td>
                            <td><?php echo $post['TenBH'] ?></td>
							<td><?php echo $post['CS'] ?></td>
                            <td><button type="button" class="btn btn-link"><a href="view_ncn.php?id1='<?php echo $post['id'] ?>'" title='Update Record' data-toggle='tooltip'><i class="fas fa-eye"></i>VIEW</a></button></td>
                            <td><button type="button" class="btn btn-link"><a href="delete_ncn.php?id1='<?php echo $post['id'] ?>'" title='Update Record' data-toggle='tooltip'><i class="fas fa-trash-alt"></i>DELETE</a></button></td>
                        </tr>
                    <?php
                    }
                    ?>
                    </tbody>
                </table>
            </div>
			<a style="margin-left: 50%;" class="btn btn-primary" href="MuZiks.php" role="button"><i class="fas fa-back"></i>Back</a>
    </div>
<?php
        }
    }
			}
?>  
<script src="js/search.js"></script>
  </body>
</html>