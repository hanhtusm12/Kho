<?php  

//login.php
session_start();
if(isset($_SESSION["name"]))
{
 header('location:MuZiks.php');
}

?>  
<html>
<head>
	<meta charset = "utf-8"/>
	<meta name ="viewport" content ="width, initial-scale:1"/>
	<title> Day la tieu de </title>
	<link rel = "stylesheet" type= "text/css" href ="login_form.css"/>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
</head>
<body>
	<div id="dn" class = "hero">
		<div class ="form-box">
			<div class="button-box">
				<div id ="btn"></div>
				<button type="button" class="toggle-btn" onclick="login()">Log In</button>
				<button type="button" class="toggle-btn" onclick="register()">Register</button>
			</div>
			<div class ="social-icons">
			<img src="./login/fb.png">
			<img src="./login/tw.png">
			<img src="./login/gp.png">
		</div>
		<form action = "NhacCaNhan.php" method="post" id="login_form" class = "input-group">
			<input type="text" name = "email" id ="email" class ="input-field" placeholder="Email Id" required>
			<input type="text" name="password" id = "password" class ="input-field" placeholder="Enter Password" required><br/>
			<div class ="er" id="error_message"></div><br/>
			<input type="checkbox" class="check-box"><span>Remember Password</span>
			<button type="submit" id = "submit" name="btn_submit" class="submit-btn">Log In</button>
			
		</form>
		<form method = "post" id="register" class = "input-group">
			<input type="email" name="email" id="email" class ="input-field" placeholder="Email Id" required>
			<input type="text" name="password" id="password" class ="input-field" placeholder="Enter Password" required>
			<div id="error_message2">dd</div><br/>
			<input type="checkbox" class="check-box"><span>I agree to the terms & conditions</span>
			<button type="submit" id = "submit" name="btn_submit" class="submit-btn">Register</button>
		</form>
		</div>
		
	</div>       
</body>
<script src="js/login.js"></script>
</html>

