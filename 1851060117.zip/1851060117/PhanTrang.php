<?php
	if ($SoTrang > 3) {
		$dau = 1;
?>
<a class ="btn btn-primary" href ="?SoSP=<?=$SoSP?>&trang=<?=$dau?>">Đầu</a>
<?php } ?>

<?php 
	if ($SoTrang > 1){
		$prev = $SoTrang -1;
?>
<a class ="btn btn-primary" href ="?SoSP=<?=$SoSP?>&trang=<?=$prev?>">Prev</a>
<?php } ?>

<?php for($num = 1; $num <= $TongTrang; $num++){ ?>
	<?php if ($num > $SoTrang - 3 && $num < $SoTrang + 3) { ?>
		<a class ="btn btn-primary" href ="?SoSP=<?=$SoSP?>&trang=<?=$num?>"><?=$num?></a>
	<?php } ?>
<?php } ?>

<?php 
	if ($SoTrang < $TongTrang -1){
		$next = $SoTrang +1;
?>
<a class ="btn btn-primary" href ="?SoSP=<?=$SoSP?>&trang=<?=$next?>">Next</a>
<?php } ?>

<?php
	if ($SoTrang < $TongTrang - 3) {
		$cuoi = $TongTrang;
?>
<a class ="btn btn-primary" href ="?SoSP=<?=$SoSP?>&trang=<?=$cuoi?>">Cuối</a>
<?php } ?>

