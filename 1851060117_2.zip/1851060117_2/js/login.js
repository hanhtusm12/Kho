var x = document.getElementById("login_form");
var y = document.getElementById("register");
var z = document.getElementById("btn");
var m = document.getElementById("dn");

let check_login = false;


function register(){
	
	x.style.left = "-400px";
	y.style.left = "50px";
	z.style.left = "110px";
}

function login(){
	
	x.style.left = "50px";
	y.style.left = "450px";
	z.style.left = "0px";
}




$(document).ready(function(){
 $('#login_form').on('submit', function(event){
  event.preventDefault();
  $.ajax({
   url:"check_login.php",
   method:"POST",
   data:$(this).serialize(),
   success:function(data){
    if(data != '')
    {
     $('#error_message').html(data);
    }
    else
    {
     window.location = 'MuZiks.php';
    }
   }
  })
 });
});


$(document).ready(function(){
 $('#register').on('submit', function(event){
  event.preventDefault();
  $.ajax({
   url:"check_register.php",
   method:"POST",
   data:$(this).serialize(),
   success:function(data){
    if(data != '')
    {
     $('#error_message2').html(data);
    }
    else
    {
     window.location = 'MuZiks.php';
    }
   }
  })
 });
});

