let check_play = false;
function check(){

	if (check_play == false){
		check_play = true;
		document.getElementById("player").style.opacity = "1";
	}
	else{
		check_play = false;
		document.getElementById("player").style.opacity = "0";
	}
}

